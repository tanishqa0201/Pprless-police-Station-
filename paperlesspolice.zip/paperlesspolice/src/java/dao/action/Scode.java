
package dao.action;


import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import struts.dao.LogicalCode;
import stuts.dto.User;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;


public class Scode extends ActionSupport implements ModelDriven
{
    User user=new User();
    public Scode(){}
    @Override
    public User getModel(){
    
    return user;
    }
    @Override
    public String execute()throws Exception
    {
//    LogicalCode logicalCode=new LogicalCode();
//    logicalCode.signupLogic(user);
//    return SUCCESS;
        SessionFactory sf=new Configuration().configure().buildSessionFactory();
        Session session=sf.openSession();
        Transaction transaction=session.beginTransaction();
        session.save(user);
        transaction.commit();
        session.close();
        return SUCCESS;
        
    
    }
}
