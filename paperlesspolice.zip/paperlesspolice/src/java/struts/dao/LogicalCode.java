
package struts.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import struts.dto.User;


public class LogicalCode
{
    public SessionFactory sessionFactory;
    public LogicalCode()throws Exception
    {
        sessionFactory=database.connection.info.load.DBConnection.getEmergencyConnection();
    }
    public void signupLogic(User user)
    {
        Session session=sessionFactory.openSession();
        Transaction transaction=session.beginTransaction();
        session.save(user);
        transaction.commit();
        session.close();
    
    }
}
