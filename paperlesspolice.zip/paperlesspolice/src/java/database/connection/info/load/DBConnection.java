
package database.connection.info.load;
import javax.swing.JOptionPane;
import org.hibernate.SessionFactory;

import org.hibernate.cfg.Configuration;


public class DBConnection
{
    static private SessionFactory sessionFactory=null;
    static
    {
        sessionFactory=new Configuration().configure().buildSessionFactory();
        JOptionPane.showMessageDialog(null, "CONNECTION ESTABLISHED");
    }
    public static SessionFactory getEmergencyConnection()throws Exception
    {
    if(sessionFactory.isClosed())
    {
            JOptionPane.showMessageDialog(null, "DISCONNECTED");
            JOptionPane.showMessageDialog(null, "CONNECTION IS LOADING AGAIN");
            Thread.sleep(5000);
            sessionFactory=new Configuration().configure().buildSessionFactory();
    }
    return sessionFactory;
    }
}
